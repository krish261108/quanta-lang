# QuantaLang

QuantaLang is a research-style language implementation with a modular toolchain:
lexer, parser, AST, optimizer, type checking, bytecode compilation, a stack VM, and an interpreter.

## Run

```bash
python -m scripts.demo
```

## Why it looks strong on GitHub

- clear separation of frontend / middle-end / backend
- lots of small modules instead of one giant file
- tests for each layer
- docs for architecture and language design
- room for serious extension: SSA, closures, modules, register allocation, and more
