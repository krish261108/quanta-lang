# Research Notes

- constant folding should be extended to algebraic simplification
- function inlining is a natural next step
- escape analysis would enable stack allocation
- closures require upvalue capture
- a register-based VM could outperform the stack VM
- the parser could be swapped for a Pratt parser rewrite
