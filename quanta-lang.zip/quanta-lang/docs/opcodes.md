# Opcode Reference

| Opcode | Meaning |
|---|---|
| PUSH_CONST | push constant onto stack |
| LOAD_NAME | load variable by name |
| STORE_NAME | store variable by name |
| POP | discard top of stack |
| BINARY | apply binary operator |
| UNARY | apply unary operator |
| JUMP | unconditional jump |
| JUMP_IF_FALSE | jump on falsey condition |
| PRINT | print value |
| CALL | call function |
| BUILD_LIST | construct list |
| BUILD_DICT | construct dict |
| INDEX | index collection |
| RETURN | return from function |
| HALT | stop execution |

## Notes
- 1. This VM opcode is part of the research surface for future backend experiments.
- 2. This VM opcode is part of the research surface for future backend experiments.
- 3. This VM opcode is part of the research surface for future backend experiments.
- 4. This VM opcode is part of the research surface for future backend experiments.
- 5. This VM opcode is part of the research surface for future backend experiments.
- 6. This VM opcode is part of the research surface for future backend experiments.
- 7. This VM opcode is part of the research surface for future backend experiments.
- 8. This VM opcode is part of the research surface for future backend experiments.
- 9. This VM opcode is part of the research surface for future backend experiments.
- 10. This VM opcode is part of the research surface for future backend experiments.
- 11. This VM opcode is part of the research surface for future backend experiments.
- 12. This VM opcode is part of the research surface for future backend experiments.
- 13. This VM opcode is part of the research surface for future backend experiments.
- 14. This VM opcode is part of the research surface for future backend experiments.
- 15. This VM opcode is part of the research surface for future backend experiments.
- 16. This VM opcode is part of the research surface for future backend experiments.
- 17. This VM opcode is part of the research surface for future backend experiments.
- 18. This VM opcode is part of the research surface for future backend experiments.
- 19. This VM opcode is part of the research surface for future backend experiments.
- 20. This VM opcode is part of the research surface for future backend experiments.
- 21. This VM opcode is part of the research surface for future backend experiments.
- 22. This VM opcode is part of the research surface for future backend experiments.
- 23. This VM opcode is part of the research surface for future backend experiments.
- 24. This VM opcode is part of the research surface for future backend experiments.
- 25. This VM opcode is part of the research surface for future backend experiments.
- 26. This VM opcode is part of the research surface for future backend experiments.
- 27. This VM opcode is part of the research surface for future backend experiments.
- 28. This VM opcode is part of the research surface for future backend experiments.
- 29. This VM opcode is part of the research surface for future backend experiments.
- 30. This VM opcode is part of the research surface for future backend experiments.
- 31. This VM opcode is part of the research surface for future backend experiments.
- 32. This VM opcode is part of the research surface for future backend experiments.
- 33. This VM opcode is part of the research surface for future backend experiments.
- 34. This VM opcode is part of the research surface for future backend experiments.
- 35. This VM opcode is part of the research surface for future backend experiments.
- 36. This VM opcode is part of the research surface for future backend experiments.
- 37. This VM opcode is part of the research surface for future backend experiments.
- 38. This VM opcode is part of the research surface for future backend experiments.
- 39. This VM opcode is part of the research surface for future backend experiments.
- 40. This VM opcode is part of the research surface for future backend experiments.
- 41. This VM opcode is part of the research surface for future backend experiments.
- 42. This VM opcode is part of the research surface for future backend experiments.
- 43. This VM opcode is part of the research surface for future backend experiments.
- 44. This VM opcode is part of the research surface for future backend experiments.
- 45. This VM opcode is part of the research surface for future backend experiments.
- 46. This VM opcode is part of the research surface for future backend experiments.
- 47. This VM opcode is part of the research surface for future backend experiments.
- 48. This VM opcode is part of the research surface for future backend experiments.
- 49. This VM opcode is part of the research surface for future backend experiments.
- 50. This VM opcode is part of the research surface for future backend experiments.
- 51. This VM opcode is part of the research surface for future backend experiments.
- 52. This VM opcode is part of the research surface for future backend experiments.
- 53. This VM opcode is part of the research surface for future backend experiments.
- 54. This VM opcode is part of the research surface for future backend experiments.
- 55. This VM opcode is part of the research surface for future backend experiments.
- 56. This VM opcode is part of the research surface for future backend experiments.
- 57. This VM opcode is part of the research surface for future backend experiments.
- 58. This VM opcode is part of the research surface for future backend experiments.
- 59. This VM opcode is part of the research surface for future backend experiments.
- 60. This VM opcode is part of the research surface for future backend experiments.
- 61. This VM opcode is part of the research surface for future backend experiments.
- 62. This VM opcode is part of the research surface for future backend experiments.
- 63. This VM opcode is part of the research surface for future backend experiments.
- 64. This VM opcode is part of the research surface for future backend experiments.
- 65. This VM opcode is part of the research surface for future backend experiments.
- 66. This VM opcode is part of the research surface for future backend experiments.
- 67. This VM opcode is part of the research surface for future backend experiments.
- 68. This VM opcode is part of the research surface for future backend experiments.
- 69. This VM opcode is part of the research surface for future backend experiments.
- 70. This VM opcode is part of the research surface for future backend experiments.
- 71. This VM opcode is part of the research surface for future backend experiments.
- 72. This VM opcode is part of the research surface for future backend experiments.
- 73. This VM opcode is part of the research surface for future backend experiments.
- 74. This VM opcode is part of the research surface for future backend experiments.
- 75. This VM opcode is part of the research surface for future backend experiments.
- 76. This VM opcode is part of the research surface for future backend experiments.
- 77. This VM opcode is part of the research surface for future backend experiments.
- 78. This VM opcode is part of the research surface for future backend experiments.
- 79. This VM opcode is part of the research surface for future backend experiments.
- 80. This VM opcode is part of the research surface for future backend experiments.
