# Architecture

QuantaLang follows a layered compiler architecture.

## Frontend
- lexer
- parser
- AST construction
- syntax diagnostics

## Middle-end
- constant folding
- dead branch elimination
- type checking
- lightweight static analysis

## Backend
- bytecode compilation
- stack machine execution
- runtime environment
- basic builtin support

## Research directions
- SSA IR
- module system
- closures and upvalues
- bytecode serialization
- native code generation
