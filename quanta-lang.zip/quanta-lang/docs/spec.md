# Language Sketch

## Statements
- let bindings
- print statements
- blocks
- if / else
- while loops
- function definitions
- return

## Expressions
- literals
- variables
- unary operators
- binary operators
- calls
- lists
- dictionaries
- indexing

## Notes
The language is intentionally small, but the implementation is organized like a serious compiler project.
