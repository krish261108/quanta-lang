# Roadmap

## Short term
- better error recovery
- function calls in VM
- closures
- module imports
- improved formatting

## Medium term
- SSA-based optimizer
- escape analysis
- native backend
- inline caches
- benchmark harness

## Long term
- incremental compilation
- language server protocol support
- multi-file projects
- package manager
