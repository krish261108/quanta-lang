"""Diagnostics placeholder for future expansion."""

VALUE = 'diagnostics'
