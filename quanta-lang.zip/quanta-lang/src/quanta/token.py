from dataclasses import dataclass
from enum import Enum, auto

class TokenKind(Enum):
    EOF = auto()
    IDENT = auto()
    NUMBER = auto()
    STRING = auto()
    TRUE = auto()
    FALSE = auto()
    LET = auto()
    FN = auto()
    IF = auto()
    ELSE = auto()
    WHILE = auto()
    RETURN = auto()
    PRINT = auto()
    PLUS = auto()
    MINUS = auto()
    STAR = auto()
    SLASH = auto()
    PERCENT = auto()
    BANG = auto()
    BANG_EQ = auto()
    EQ = auto()
    EQ_EQ = auto()
    LT = auto()
    LT_EQ = auto()
    GT = auto()
    GT_EQ = auto()
    AND_AND = auto()
    OR_OR = auto()
    COMMA = auto()
    DOT = auto()
    COLON = auto()
    SEMI = auto()
    ARROW = auto()
    LPAREN = auto()
    RPAREN = auto()
    LBRACE = auto()
    RBRACE = auto()
    LBRACKET = auto()
    RBRACKET = auto()

KEYWORDS = {
    'let': TokenKind.LET,
    'fn': TokenKind.FN,
    'if': TokenKind.IF,
    'else': TokenKind.ELSE,
    'while': TokenKind.WHILE,
    'return': TokenKind.RETURN,
    'print': TokenKind.PRINT,
    'true': TokenKind.TRUE,
    'false': TokenKind.FALSE,
}

@dataclass(slots=True)
class Token:
    kind: TokenKind
    lexeme: str
    literal: object | None
    line: int
    column: int
