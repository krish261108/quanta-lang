"""Front End placeholder for future expansion."""

VALUE = 'front_end'
