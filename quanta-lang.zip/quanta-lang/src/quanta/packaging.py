"""Packaging placeholder for future expansion."""

VALUE = 'packaging'
