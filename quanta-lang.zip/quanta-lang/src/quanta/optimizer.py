from .ast import *

class Optimizer:
    def optimize_program(self, program: Program) -> Program:
        return Program([self.optimize_stmt(s) for s in program.statements])

    def optimize_stmt(self, stmt):
        if isinstance(stmt, Block):
            return Block([self.optimize_stmt(s) for s in stmt.statements])
        if isinstance(stmt, Let):
            return Let(stmt.name, self.optimize_expr(stmt.value) if stmt.value else None, stmt.annotation)
        if isinstance(stmt, ExprStmt):
            return ExprStmt(self.optimize_expr(stmt.expr))
        if isinstance(stmt, Print):
            return Print(self.optimize_expr(stmt.expr))
        if isinstance(stmt, If):
            cond = self.optimize_expr(stmt.cond)
            then_branch = self.optimize_stmt(stmt.then_branch)
            else_branch = self.optimize_stmt(stmt.else_branch) if stmt.else_branch else None
            if isinstance(cond, Literal):
                return then_branch if cond.value else else_branch or Block([])
            return If(cond, then_branch, else_branch)
        if isinstance(stmt, While):
            return While(self.optimize_expr(stmt.cond), self.optimize_stmt(stmt.body))
        if isinstance(stmt, Return):
            return Return(self.optimize_expr(stmt.value) if stmt.value else None)
        if isinstance(stmt, Function):
            return Function(stmt.name, stmt.params, self.optimize_stmt(stmt.body), stmt.return_annotation)
        return stmt

    def optimize_expr(self, expr):
        if expr is None: return None
        if isinstance(expr, Grouping):
            return self.optimize_expr(expr.expr)
        if isinstance(expr, Unary):
            right = self.optimize_expr(expr.right)
            if isinstance(right, Literal):
                if expr.op == '-': return Literal(-right.value)
                if expr.op == '!': return Literal(not right.value)
            return Unary(expr.op, right)
        if isinstance(expr, Binary):
            left = self.optimize_expr(expr.left)
            right = self.optimize_expr(expr.right)
            if isinstance(left, Literal) and isinstance(right, Literal):
                try:
                    from .runtime.interpreter import Interpreter
                    return Literal(Interpreter()._binary(left.value, expr.op, right.value))
                except Exception:
                    pass
            return Binary(left, expr.op, right)
        if isinstance(expr, Assign):
            return Assign(expr.name, self.optimize_expr(expr.value))
        if isinstance(expr, Call):
            return Call(self.optimize_expr(expr.callee), [self.optimize_expr(a) for a in expr.args])
        if isinstance(expr, ListLiteral):
            return ListLiteral([self.optimize_expr(i) for i in expr.items])
        if isinstance(expr, DictLiteral):
            return DictLiteral([(self.optimize_expr(k), self.optimize_expr(v)) for k, v in expr.items])
        if isinstance(expr, Index):
            return Index(self.optimize_expr(expr.target), self.optimize_expr(expr.index))
        return expr
