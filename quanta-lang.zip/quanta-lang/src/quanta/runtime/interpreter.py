from __future__ import annotations

from dataclasses import dataclass

from ..ast import *
from ..errors import RuntimeQuantaError
from .environment import Environment

@dataclass
class ReturnSignal(Exception):
    value: object

class CallableFunction:
    def __init__(self, node: Function, closure: Environment, interpreter: 'Interpreter'):
        self.node = node
        self.closure = closure
        self.interpreter = interpreter

    def __call__(self, args):
        env = Environment(self.closure)
        for param, arg in zip(self.node.params, args):
            env.define(param.name, arg)
        try:
            self.interpreter._execute_block(self.node.body.statements, env)
        except ReturnSignal as r:
            return r.value
        return None

class Builtin:
    def __init__(self, fn):
        self.fn = fn
    def __call__(self, args):
        return self.fn(*args)

class Interpreter:
    def __init__(self):
        self.globals = Environment()
        self.env = self.globals
        self._install_builtins()

    def _install_builtins(self):
        self.globals.define('len', Builtin(lambda x: len(x)))
        self.globals.define('sqrt', Builtin(lambda x: x ** 0.5))
        self.globals.define('push', Builtin(lambda lst, x: lst.append(x) or lst))
        self.globals.define('pop', Builtin(lambda lst: lst.pop()))

    def run(self, program: Program):
        result = None
        for stmt in program.statements:
            result = self.execute(stmt)
        return result

    def execute(self, stmt):
        if isinstance(stmt, Block):
            return self._execute_block(stmt.statements, Environment(self.env))
        if isinstance(stmt, Let):
            value = self.evaluate(stmt.value) if stmt.value is not None else None
            self.env.define(stmt.name, value)
            return value
        if isinstance(stmt, ExprStmt):
            return self.evaluate(stmt.expr)
        if isinstance(stmt, Print):
            value = self.evaluate(stmt.expr)
            print(value)
            return value
        if isinstance(stmt, If):
            if self._truthy(self.evaluate(stmt.cond)):
                return self._execute_block(stmt.then_branch.statements, Environment(self.env))
            if stmt.else_branch is not None:
                return self._execute_block(stmt.else_branch.statements, Environment(self.env))
            return None
        if isinstance(stmt, While):
            result = None
            while self._truthy(self.evaluate(stmt.cond)):
                result = self._execute_block(stmt.body.statements, Environment(self.env))
            return result
        if isinstance(stmt, Return):
            raise ReturnSignal(self.evaluate(stmt.value) if stmt.value is not None else None)
        if isinstance(stmt, Function):
            self.env.define(stmt.name, CallableFunction(stmt, self.env, self))
            return None
        raise RuntimeQuantaError(f'Unsupported statement: {stmt!r}')

    def _execute_block(self, statements, env):
        previous = self.env
        self.env = env
        try:
            result = None
            for stmt in statements:
                result = self.execute(stmt)
            return result
        finally:
            self.env = previous

    def evaluate(self, expr):
        if isinstance(expr, Literal): return expr.value
        if isinstance(expr, Variable): return self.env.get(expr.name)
        if isinstance(expr, Grouping): return self.evaluate(expr.expr)
        if isinstance(expr, Assign):
            value = self.evaluate(expr.value)
            self.env.assign(expr.name, value)
            return value
        if isinstance(expr, Unary):
            right = self.evaluate(expr.right)
            if expr.op == '-': return -right
            if expr.op == '!': return not self._truthy(right)
            raise RuntimeQuantaError(f'Unknown unary operator {expr.op}')
        if isinstance(expr, Binary):
            left = self.evaluate(expr.left)
            right = self.evaluate(expr.right)
            return self._binary(left, expr.op, right)
        if isinstance(expr, Call):
            callee = self.evaluate(expr.callee)
            args = [self.evaluate(a) for a in expr.args]
            if callable(callee): return callee(args)
            raise RuntimeQuantaError('Attempted to call a non-callable value')
        if isinstance(expr, ListLiteral):
            return [self.evaluate(i) for i in expr.items]
        if isinstance(expr, DictLiteral):
            return {self.evaluate(k): self.evaluate(v) for k, v in expr.items}
        if isinstance(expr, Index):
            target = self.evaluate(expr.target)
            index = self.evaluate(expr.index)
            return target[index]
        return expr

    def _binary(self, left, op, right):
        if op == '+': return left + right
        if op == '-': return left - right
        if op == '*': return left * right
        if op == '/': return left / right
        if op == '%': return left % right
        if op == '==': return left == right
        if op == '!=': return left != right
        if op == '<': return left < right
        if op == '<=': return left <= right
        if op == '>': return left > right
        if op == '>=': return left >= right
        if op == '&&': return self._truthy(left) and self._truthy(right)
        if op == '||': return self._truthy(left) or self._truthy(right)
        raise RuntimeQuantaError(f'Unknown binary operator {op}')

    def _truthy(self, value):
        return bool(value)
