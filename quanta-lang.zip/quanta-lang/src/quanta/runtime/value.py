from dataclasses import dataclass

class Value:
    pass

@dataclass(slots=True)
class Number(Value):
    value: float | int

@dataclass(slots=True)
class String(Value):
    value: str

@dataclass(slots=True)
class Bool(Value):
    value: bool

@dataclass(slots=True)
class ListValue(Value):
    items: list[Value]

@dataclass(slots=True)
class DictValue(Value):
    items: dict[object, Value]
