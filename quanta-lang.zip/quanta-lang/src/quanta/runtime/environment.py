from .value import Value
from ..errors import RuntimeQuantaError

class Environment:
    def __init__(self, parent=None):
        self.parent = parent
        self.values: dict[str, object] = {}

    def define(self, name: str, value: object):
        self.values[name] = value

    def assign(self, name: str, value: object):
        if name in self.values:
            self.values[name] = value
            return
        if self.parent is not None:
            self.parent.assign(name, value)
            return
        raise RuntimeQuantaError(f'Undefined variable {name}')

    def get(self, name: str):
        if name in self.values:
            return self.values[name]
        if self.parent is not None:
            return self.parent.get(name)
        raise RuntimeQuantaError(f'Undefined variable {name}')
