from .ast import *
from .errors import ParserError
from .token import TokenKind

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.current = 0

    def parse(self) -> Program:
        statements = []
        while not self._check(TokenKind.EOF):
            statements.append(self._declaration())
        return Program(statements)

    def _declaration(self):
        if self._match(TokenKind.LET): return self._let_decl()
        if self._match(TokenKind.FN): return self._fn_decl()
        return self._statement()

    def _let_decl(self):
        name = self._consume(TokenKind.IDENT, 'Expected variable name')
        annotation = None
        if self._match(TokenKind.COLON):
            annotation = self._consume(TokenKind.IDENT, 'Expected type annotation').lexeme
        value = None
        if self._match(TokenKind.EQ):
            value = self._expression()
        self._consume(TokenKind.SEMI, 'Expected ; after let')
        return Let(name.lexeme, value, annotation)

    def _fn_decl(self):
        name = self._consume(TokenKind.IDENT, 'Expected function name')
        self._consume(TokenKind.LPAREN, 'Expected (')
        params = []
        if not self._check(TokenKind.RPAREN):
            while True:
                p = self._consume(TokenKind.IDENT, 'Expected parameter name')
                ann = None
                if self._match(TokenKind.COLON):
                    ann = self._consume(TokenKind.IDENT, 'Expected type').lexeme
                params.append(Param(p.lexeme, ann))
                if not self._match(TokenKind.COMMA): break
        self._consume(TokenKind.RPAREN, 'Expected )')
        ret_ann = None
        if self._match(TokenKind.ARROW):
            ret_ann = self._consume(TokenKind.IDENT, 'Expected return type').lexeme
        body = self._block()
        return Function(name.lexeme, params, body, ret_ann)

    def _statement(self):
        if self._match(TokenKind.PRINT):
            expr = self._expression()
            self._consume(TokenKind.SEMI, 'Expected ; after print')
            return Print(expr)
        if self._match(TokenKind.RETURN):
            value = None if self._check(TokenKind.SEMI) else self._expression()
            self._consume(TokenKind.SEMI, 'Expected ; after return')
            return Return(value)
        if self._match(TokenKind.IF):
            self._consume(TokenKind.LPAREN, 'Expected (')
            cond = self._expression()
            self._consume(TokenKind.RPAREN, 'Expected )')
            then_branch = self._block()
            else_branch = self._block() if self._match(TokenKind.ELSE) else None
            return If(cond, then_branch, else_branch)
        if self._match(TokenKind.WHILE):
            self._consume(TokenKind.LPAREN, 'Expected (')
            cond = self._expression()
            self._consume(TokenKind.RPAREN, 'Expected )')
            body = self._block()
            return While(cond, body)
        if self._check(TokenKind.LBRACE):
            return self._block()
        expr = self._expression()
        self._consume(TokenKind.SEMI, 'Expected ; after expression')
        return ExprStmt(expr)

    def _block(self):
        self._consume(TokenKind.LBRACE, 'Expected {')
        statements = []
        while not self._check(TokenKind.RBRACE) and not self._check(TokenKind.EOF):
            statements.append(self._declaration())
        self._consume(TokenKind.RBRACE, 'Expected }')
        return Block(statements)

    def _expression(self):
        return self._assignment()

    def _assignment(self):
        expr = self._or()
        if self._match(TokenKind.EQ):
            value = self._assignment()
            if isinstance(expr, Variable):
                return Assign(expr.name, value)
            raise ParserError('Invalid assignment target')
        return expr

    def _or(self):
        expr = self._and()
        while self._match(TokenKind.OR_OR):
            op = '||'
            right = self._and()
            expr = Binary(expr, op, right)
        return expr

    def _and(self):
        expr = self._equality()
        while self._match(TokenKind.AND_AND):
            op = '&&'
            right = self._equality()
            expr = Binary(expr, op, right)
        return expr

    def _equality(self):
        expr = self._comparison()
        while self._match(TokenKind.BANG_EQ, TokenKind.EQ_EQ):
            op = '!=' if self._previous().kind == TokenKind.BANG_EQ else '=='
            right = self._comparison()
            expr = Binary(expr, op, right)
        return expr

    def _comparison(self):
        expr = self._term()
        while self._match(TokenKind.GT, TokenKind.GT_EQ, TokenKind.LT, TokenKind.LT_EQ):
            kind = self._previous().kind
            op = {'>':'>','>=':'>=','<':'<','<=':'<='}[self._tok(kind)]
            right = self._term()
            expr = Binary(expr, op, right)
        return expr

    def _term(self):
        expr = self._factor()
        while self._match(TokenKind.PLUS, TokenKind.MINUS):
            op = self._tok(self._previous().kind)
            right = self._factor()
            expr = Binary(expr, op, right)
        return expr

    def _factor(self):
        expr = self._unary()
        while self._match(TokenKind.STAR, TokenKind.SLASH, TokenKind.PERCENT):
            op = self._tok(self._previous().kind)
            right = self._unary()
            expr = Binary(expr, op, right)
        return expr

    def _unary(self):
        if self._match(TokenKind.BANG, TokenKind.MINUS):
            op = self._tok(self._previous().kind)
            return Unary(op, self._unary())
        return self._call()

    def _call(self):
        expr = self._primary()
        while True:
            if self._match(TokenKind.LPAREN):
                args = []
                if not self._check(TokenKind.RPAREN):
                    while True:
                        args.append(self._expression())
                        if not self._match(TokenKind.COMMA): break
                self._consume(TokenKind.RPAREN, 'Expected ) after args')
                expr = Call(expr, args)
            elif self._match(TokenKind.LBRACKET):
                idx = self._expression()
                self._consume(TokenKind.RBRACKET, 'Expected ]')
                expr = Index(expr, idx)
            else:
                break
        return expr

    def _primary(self):
        if self._match(TokenKind.NUMBER, TokenKind.STRING, TokenKind.TRUE, TokenKind.FALSE):
            tok = self._previous()
            return Literal(tok.literal)
        if self._match(TokenKind.IDENT):
            return Variable(self._previous().lexeme)
        if self._match(TokenKind.LPAREN):
            expr = self._expression()
            self._consume(TokenKind.RPAREN, 'Expected )')
            return Grouping(expr)
        if self._match(TokenKind.LBRACKET):
            items = []
            if not self._check(TokenKind.RBRACKET):
                while True:
                    items.append(self._expression())
                    if not self._match(TokenKind.COMMA): break
            self._consume(TokenKind.RBRACKET, 'Expected ]')
            return ListLiteral(items)
        if self._match(TokenKind.LBRACE):
            items = []
            if not self._check(TokenKind.RBRACE):
                while True:
                    k = self._expression()
                    self._consume(TokenKind.COLON, 'Expected : in dict')
                    v = self._expression()
                    items.append((k, v))
                    if not self._match(TokenKind.COMMA): break
            self._consume(TokenKind.RBRACE, 'Expected }')
            return DictLiteral(items)
        raise ParserError(f'Expected expression at token {self._peek().lexeme!r}')

    def _match(self, *kinds):
        for kind in kinds:
            if self._check(kind):
                self.current += 1
                return True
        return False

    def _consume(self, kind, message):
        if self._check(kind):
            self.current += 1
            return self._previous()
        raise ParserError(message)

    def _check(self, kind):
        return not self._is_at_end() and self._peek().kind == kind

    def _is_at_end(self):
        return self._peek().kind == TokenKind.EOF

    def _peek(self):
        return self.tokens[self.current]

    def _previous(self):
        return self.tokens[self.current - 1]

    def _tok(self, kind):
        return {
            TokenKind.PLUS: '+', TokenKind.MINUS: '-', TokenKind.STAR: '*', TokenKind.SLASH: '/', TokenKind.PERCENT: '%',
            TokenKind.EQ_EQ: '==', TokenKind.BANG_EQ: '!=', TokenKind.GT: '>', TokenKind.GT_EQ: '>=', TokenKind.LT: '<', TokenKind.LT_EQ: '<=',
        }[kind]
