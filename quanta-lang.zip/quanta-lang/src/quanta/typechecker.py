from dataclasses import dataclass
from .ast import *
from .errors import TypeQuantaError

@dataclass(frozen=True)
class Type:
    name: str

Int = Type('Int')
Float = Type('Float')
Bool = Type('Bool')
String = Type('String')
AnyT = Type('Any')
ListT = lambda t: Type(f'List[{t.name}]')
DictT = lambda k, v: Type(f'Dict[{k.name},{v.name}]')

class TypeEnv:
    def __init__(self, parent=None):
        self.parent = parent
        self.values: dict[str, Type] = {}
    def define(self, name, typ): self.values[name] = typ
    def get(self, name):
        if name in self.values: return self.values[name]
        if self.parent: return self.parent.get(name)
        return AnyT

class TypeChecker:
    def __init__(self):
        self.env = TypeEnv()
        self.env.define('len', AnyT)
        self.env.define('sqrt', AnyT)

    def check(self, program: Program):
        for stmt in program.statements:
            self.check_stmt(stmt)

    def check_stmt(self, stmt):
        if isinstance(stmt, Let):
            t = self.check_expr(stmt.value) if stmt.value else AnyT
            self.env.define(stmt.name, t)
            return t
        if isinstance(stmt, ExprStmt): return self.check_expr(stmt.expr)
        if isinstance(stmt, Print): return self.check_expr(stmt.expr)
        if isinstance(stmt, Block):
            child = TypeEnv(self.env)
            old = self.env
            self.env = child
            try:
                for s in stmt.statements: self.check_stmt(s)
            finally:
                self.env = old
            return AnyT
        if isinstance(stmt, If):
            self.check_expr(stmt.cond)
            self.check_stmt(stmt.then_branch)
            if stmt.else_branch: self.check_stmt(stmt.else_branch)
            return AnyT
        if isinstance(stmt, While):
            self.check_expr(stmt.cond)
            self.check_stmt(stmt.body)
            return AnyT
        if isinstance(stmt, Function):
            self.env.define(stmt.name, AnyT)
            return AnyT
        if isinstance(stmt, Return):
            return self.check_expr(stmt.value) if stmt.value else AnyT
        return AnyT

    def check_expr(self, expr):
        if expr is None: return AnyT
        if isinstance(expr, Literal):
            if isinstance(expr.value, bool): return Bool
            if isinstance(expr.value, int): return Int
            if isinstance(expr.value, float): return Float
            if isinstance(expr.value, str): return String
            return AnyT
        if isinstance(expr, Variable): return self.env.get(expr.name)
        if isinstance(expr, Grouping): return self.check_expr(expr.expr)
        if isinstance(expr, Assign):
            t = self.check_expr(expr.value)
            self.env.define(expr.name, t)
            return t
        if isinstance(expr, Unary): return self.check_expr(expr.right)
        if isinstance(expr, Binary):
            l = self.check_expr(expr.left); r = self.check_expr(expr.right)
            if expr.op in ['+','-','*','/','%','<','<=','>','>=','==','!=','&&','||']:
                return Bool if expr.op in ['<','<=','>','>=','==','!=','&&','||'] else l if l == r else AnyT
            return AnyT
        if isinstance(expr, Call): return AnyT
        if isinstance(expr, ListLiteral): return ListT(self.check_expr(expr.items[0]) if expr.items else AnyT)
        if isinstance(expr, DictLiteral): return DictT(AnyT, AnyT)
        if isinstance(expr, Index): return AnyT
        raise TypeQuantaError(f'Cannot infer type for {expr!r}')
