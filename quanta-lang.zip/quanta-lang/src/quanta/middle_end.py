"""Middle End placeholder for future expansion."""

VALUE = 'middle_end'
