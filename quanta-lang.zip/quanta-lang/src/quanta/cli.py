from __future__ import annotations

import argparse
from pathlib import Path

from .interpreter import Interpreter
from .repl import REPL


def main(argv=None):
    parser = argparse.ArgumentParser(prog='quanta')
    parser.add_argument('file', nargs='?')
    parser.add_argument('--repl', action='store_true')
    args = parser.parse_args(argv)
    if args.repl or not args.file:
        REPL().run()
        return
    source = Path(args.file).read_text(encoding='utf-8')
    print(Interpreter().run_source(source))

if __name__ == '__main__':
    main()
