from __future__ import annotations

from .interpreter import Interpreter

PROMPT = 'quanta> '

class REPL:
    def __init__(self):
        self.interpreter = Interpreter()

    def run(self):
        print('QuantaLang REPL. Type :quit to exit.')
        while True:
            try:
                line = input(PROMPT)
            except EOFError:
                break
            if line.strip() in {':quit', ':q'}:
                break
            if not line.strip():
                continue
            try:
                result = self.interpreter.run_source(line)
                if result is not None:
                    print(result)
            except Exception as e:
                print(type(e).__name__ + ':', e)
