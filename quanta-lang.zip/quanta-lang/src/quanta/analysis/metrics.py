from dataclasses import dataclass
from ..compiler.bytecode import CodeObject

@dataclass(slots=True)
class Metrics:
    instructions: int
    constants: int
    names: int


def summarize(code: CodeObject) -> Metrics:
    return Metrics(len(code.instructions), len(code.constants), len(code.names))
