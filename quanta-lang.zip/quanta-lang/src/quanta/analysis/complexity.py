from .metrics import Metrics


def cyclomatic_like(source: str) -> int:
    score = 1
    score += source.count('if ')
    score += source.count('while ')
    score += source.count('fn ')
    score += source.count('&&')
    score += source.count('||')
    return score
