from .ast import *

class Formatter:
    def format_program(self, program: Program) -> str:
        return '
'.join(self.format_stmt(s, 0) for s in program.statements)

    def format_stmt(self, stmt, indent: int) -> str:
        pad = '    ' * indent
        if isinstance(stmt, Let):
            if stmt.value is None:
                return f'{pad}let {stmt.name};'
            return f'{pad}let {stmt.name} = {self.format_expr(stmt.value)};'
        if isinstance(stmt, ExprStmt):
            return f'{pad}{self.format_expr(stmt.expr)};'
        if isinstance(stmt, Print):
            return f'{pad}print {self.format_expr(stmt.expr)};'
        if isinstance(stmt, Return):
            return f'{pad}return {"" if stmt.value is None else self.format_expr(stmt.value)};'
        if isinstance(stmt, Block):
            body = '
'.join(self.format_stmt(s, indent + 1) for s in stmt.statements)
            return pad + '{
' + body + ('
' if body else '') + pad + '}'
        if isinstance(stmt, If):
            s = f'{pad}if ({self.format_expr(stmt.cond)}) ' + self.format_stmt(stmt.then_branch, indent)
            if stmt.else_branch:
                s += ' else ' + self.format_stmt(stmt.else_branch, indent)
            return s
        if isinstance(stmt, While):
            return f'{pad}while ({self.format_expr(stmt.cond)}) ' + self.format_stmt(stmt.body, indent)
        if isinstance(stmt, Function):
            params = ', '.join(self.format_param(p) for p in stmt.params)
            head = f'{pad}fn {stmt.name}({params})'
            if stmt.return_annotation:
                head += f' -> {stmt.return_annotation}'
            return head + ' ' + self.format_stmt(stmt.body, indent)
        return pad + repr(stmt)

    def format_param(self, param: Param) -> str:
        if param.annotation:
            return f'{param.name}: {param.annotation}'
        return param.name

    def format_expr(self, expr) -> str:
        if isinstance(expr, Literal): return repr(expr.value)
        if isinstance(expr, Variable): return expr.name
        if isinstance(expr, Grouping): return f'({self.format_expr(expr.expr)})'
        if isinstance(expr, Assign): return f'{expr.name} = {self.format_expr(expr.value)}'
        if isinstance(expr, Unary): return f'({expr.op}{self.format_expr(expr.right)})'
        if isinstance(expr, Binary): return f'({self.format_expr(expr.left)} {expr.op} {self.format_expr(expr.right)})'
        if isinstance(expr, Call): return f'{self.format_expr(expr.callee)}({", ".join(self.format_expr(a) for a in expr.args)})'
        if isinstance(expr, ListLiteral): return '[' + ', '.join(self.format_expr(i) for i in expr.items) + ']'
        if isinstance(expr, DictLiteral): return '{' + ', '.join(f'{self.format_expr(k)}: {self.format_expr(v)}' for k, v in expr.items) + '}'
        if isinstance(expr, Index): return f'{self.format_expr(expr.target)}[{self.format_expr(expr.index)}]'
        return repr(expr)
