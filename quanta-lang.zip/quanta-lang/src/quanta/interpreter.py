from __future__ import annotations

from .lexer import Lexer
from .parser import Parser
from .optimizer import Optimizer
from .typechecker import TypeChecker
from .runtime.interpreter import Interpreter as TreeInterpreter

class Interpreter:
    def __init__(self):
        self.tree = TreeInterpreter()
        self.optimizer = Optimizer()
        self.typechecker = TypeChecker()

    def run_source(self, source: str):
        program = Parser(Lexer(source).tokenize()).parse()
        self.typechecker.check(program)
        program = self.optimizer.optimize_program(program)
        return self.tree.run(program)
