import math

BUILTINS = {
    'pi': math.pi,
    'e': math.e,
    'abs': abs,
    'min': min,
    'max': max,
    'sum': sum,
    'len': len,
    'sqrt': lambda x: x ** 0.5,
    'range': range,
}
