"""Profiling placeholder for future expansion."""

VALUE = 'profiling'
