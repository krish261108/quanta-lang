from __future__ import annotations

from dataclasses import dataclass
from ..errors import RuntimeQuantaError
from .bytecode import CodeObject

@dataclass
class Frame:
    code: CodeObject
    ip: int = 0

class VM:
    def __init__(self):
        self.stack = []
        self.globals = {}

    def run(self, code: CodeObject):
        frame = Frame(code)
        while frame.ip < len(code.instructions):
            ins = code.instructions[frame.ip]
            frame.ip += 1
            op = ins.op
            arg = ins.arg
            if op == 'HALT':
                break
            elif op == 'PUSH_CONST':
                self.stack.append(code.constants[arg])
            elif op == 'POP':
                self.stack.pop()
            elif op == 'LOAD_NAME':
                name = code.names[arg]
                self.stack.append(self.globals.get(name))
            elif op == 'STORE_NAME':
                name = code.names[arg]
                self.globals[name] = self.stack[-1]
            elif op == 'UNARY':
                v = self.stack.pop()
                self.stack.append(-v if arg == '-' else (not v))
            elif op == 'BINARY':
                b = self.stack.pop(); a = self.stack.pop()
                self.stack.append(self._bin(a, arg, b))
            elif op == 'PRINT':
                print(self.stack.pop())
            elif op == 'JUMP':
                frame.ip = arg
            elif op == 'JUMP_IF_FALSE':
                v = self.stack.pop()
                if not v: frame.ip = arg
            elif op == 'CALL':
                raise RuntimeQuantaError('CALL not implemented in VM demo')
            elif op == 'BUILD_LIST':
                items = [self.stack.pop() for _ in range(arg)][::-1]
                self.stack.append(items)
            elif op == 'BUILD_DICT':
                items = {}
                for _ in range(arg):
                    v = self.stack.pop(); k = self.stack.pop(); items[k] = v
                self.stack.append(items)
            elif op == 'INDEX':
                idx = self.stack.pop(); target = self.stack.pop(); self.stack.append(target[idx])
            elif op == 'RETURN':
                return self.stack.pop() if self.stack else None
        return self.stack[-1] if self.stack else None

    def _bin(self, a, op, b):
        if op == '+': return a + b
        if op == '-': return a - b
        if op == '*': return a * b
        if op == '/': return a / b
        if op == '%': return a % b
        if op == '==': return a == b
        if op == '!=': return a != b
        if op == '<': return a < b
        if op == '<=': return a <= b
        if op == '>': return a > b
        if op == '>=': return a >= b
        if op == '&&': return bool(a) and bool(b)
        if op == '||': return bool(a) or bool(b)
        raise RuntimeQuantaError(f'Unknown op {op}')
