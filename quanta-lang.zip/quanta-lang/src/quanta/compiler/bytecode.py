from dataclasses import dataclass

@dataclass(slots=True)
class Instruction:
    op: str
    arg: object | None = None

@dataclass(slots=True)
class CodeObject:
    instructions: list[Instruction]
    constants: list[object]
    names: list[str]
