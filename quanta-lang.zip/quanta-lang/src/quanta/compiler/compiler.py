from __future__ import annotations

from dataclasses import dataclass
from .bytecode import CodeObject, Instruction
from ..ast import *

class Compiler:
    def __init__(self):
        self.constants: list[object] = []
        self.names: list[str] = []
        self.instructions: list[Instruction] = []

    def compile(self, program: Program) -> CodeObject:
        for stmt in program.statements:
            self._stmt(stmt)
        self.emit('HALT')
        return CodeObject(self.instructions, self.constants, self.names)

    def emit(self, op, arg=None):
        self.instructions.append(Instruction(op, arg))

    def const(self, value):
        self.constants.append(value)
        return len(self.constants) - 1

    def name(self, name):
        if name not in self.names:
            self.names.append(name)
        return self.names.index(name)

    def _stmt(self, stmt):
        if isinstance(stmt, Let):
            if stmt.value is not None:
                self._expr(stmt.value)
            else:
                self.emit('PUSH_CONST', self.const(None))
            self.emit('STORE_NAME', self.name(stmt.name))
        elif isinstance(stmt, ExprStmt):
            self._expr(stmt.expr)
            self.emit('POP')
        elif isinstance(stmt, Print):
            self._expr(stmt.expr)
            self.emit('PRINT')
        elif isinstance(stmt, Block):
            for s in stmt.statements: self._stmt(s)
        elif isinstance(stmt, If):
            self._expr(stmt.cond)
            jmp_false = len(self.instructions)
            self.emit('JUMP_IF_FALSE', None)
            self._stmt(stmt.then_branch)
            jmp_end = len(self.instructions)
            self.emit('JUMP', None)
            self.instructions[jmp_false].arg = len(self.instructions)
            if stmt.else_branch:
                self._stmt(stmt.else_branch)
            self.instructions[jmp_end].arg = len(self.instructions)
        elif isinstance(stmt, While):
            loop_start = len(self.instructions)
            self._expr(stmt.cond)
            jmp_false = len(self.instructions)
            self.emit('JUMP_IF_FALSE', None)
            self._stmt(stmt.body)
            self.emit('JUMP', loop_start)
            self.instructions[jmp_false].arg = len(self.instructions)
        elif isinstance(stmt, Function):
            idx = self.const(stmt)
            self.emit('PUSH_CONST', idx)
            self.emit('STORE_NAME', self.name(stmt.name))
        elif isinstance(stmt, Return):
            if stmt.value is not None:
                self._expr(stmt.value)
            else:
                self.emit('PUSH_CONST', self.const(None))
            self.emit('RETURN')

    def _expr(self, expr):
        if isinstance(expr, Literal):
            self.emit('PUSH_CONST', self.const(expr.value))
        elif isinstance(expr, Variable):
            self.emit('LOAD_NAME', self.name(expr.name))
        elif isinstance(expr, Grouping):
            self._expr(expr.expr)
        elif isinstance(expr, Assign):
            self._expr(expr.value)
            self.emit('STORE_NAME', self.name(expr.name))
        elif isinstance(expr, Unary):
            self._expr(expr.right)
            self.emit('UNARY', expr.op)
        elif isinstance(expr, Binary):
            self._expr(expr.left)
            self._expr(expr.right)
            self.emit('BINARY', expr.op)
        elif isinstance(expr, Call):
            self._expr(expr.callee)
            for a in expr.args: self._expr(a)
            self.emit('CALL', len(expr.args))
        elif isinstance(expr, ListLiteral):
            for item in expr.items: self._expr(item)
            self.emit('BUILD_LIST', len(expr.items))
        elif isinstance(expr, DictLiteral):
            for k, v in expr.items:
                self._expr(k); self._expr(v)
            self.emit('BUILD_DICT', len(expr.items))
        elif isinstance(expr, Index):
            self._expr(expr.target)
            self._expr(expr.index)
            self.emit('INDEX')
