"""Back End placeholder for future expansion."""

VALUE = 'back_end'
