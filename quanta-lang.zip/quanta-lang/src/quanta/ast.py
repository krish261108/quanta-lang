from dataclasses import dataclass, field
from typing import Any

class Stmt:
    pass

class Expr:
    pass

@dataclass(slots=True)
class Program:
    statements: list[Stmt]

@dataclass(slots=True)
class Literal(Expr):
    value: Any

@dataclass(slots=True)
class Variable(Expr):
    name: str

@dataclass(slots=True)
class Unary(Expr):
    op: str
    right: Expr

@dataclass(slots=True)
class Binary(Expr):
    left: Expr
    op: str
    right: Expr

@dataclass(slots=True)
class Grouping(Expr):
    expr: Expr

@dataclass(slots=True)
class Assign(Expr):
    name: str
    value: Expr

@dataclass(slots=True)
class Call(Expr):
    callee: Expr
    args: list[Expr]

@dataclass(slots=True)
class ListLiteral(Expr):
    items: list[Expr]

@dataclass(slots=True)
class DictLiteral(Expr):
    items: list[tuple[Expr, Expr]]

@dataclass(slots=True)
class Index(Expr):
    target: Expr
    index: Expr

@dataclass(slots=True)
class Block(Stmt):
    statements: list[Stmt] = field(default_factory=list)

@dataclass(slots=True)
class Let(Stmt):
    name: str
    value: Expr | None
    annotation: str | None = None

@dataclass(slots=True)
class ExprStmt(Stmt):
    expr: Expr

@dataclass(slots=True)
class Print(Stmt):
    expr: Expr

@dataclass(slots=True)
class If(Stmt):
    cond: Expr
    then_branch: Block
    else_branch: Block | None = None

@dataclass(slots=True)
class While(Stmt):
    cond: Expr
    body: Block

@dataclass(slots=True)
class Return(Stmt):
    value: Expr | None

@dataclass(slots=True)
class Param:
    name: str
    annotation: str | None = None

@dataclass(slots=True)
class Function(Stmt):
    name: str
    params: list[Param]
    body: Block
    return_annotation: str | None = None
