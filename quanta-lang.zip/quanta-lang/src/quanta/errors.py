class QuantaError(Exception):
    pass

class LexerError(QuantaError):
    pass

class ParserError(QuantaError):
    pass

class TypeQuantaError(QuantaError):
    pass

class RuntimeQuantaError(QuantaError):
    pass
