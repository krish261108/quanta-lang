from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter
from quanta.compiler import Compiler
from quanta.vm import VM
from quanta.optimizer import Optimizer
from quanta.typechecker import TypeChecker

def test_case5_0():
    source = 'let x = 1 + 2;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_1():
    source = 'let y = 4 * 5;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_2():
    source = 'print 1 + 1;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_3():
    source = 'let a = [1, 2, 3];'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_4():
    source = 'let d = {1: 2};'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_5():
    source = 'if (true) { let z = 3; } else { let z = 4; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_6():
    source = 'while (false) { let n = 0; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_7():
    source = 'fn add(a, b) { return a + b; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_8():
    source = 'let s = "hello";'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_9():
    source = 'let b = !false;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_10():
    source = 'let x = 1 + 2; // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_11():
    source = 'let y = 4 * 5; // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_12():
    source = 'print 1 + 1; // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_13():
    source = 'let a = [1, 2, 3]; // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_14():
    source = 'let d = {1: 2}; // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_15():
    source = 'if (true) { let z = 3; } else { let z = 4; } // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_16():
    source = 'while (false) { let n = 0; } // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_17():
    source = 'fn add(a, b) { return a + b; } // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_18():
    source = 'let s = "hello"; // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case5_19():
    source = 'let b = !false; // 5'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None
