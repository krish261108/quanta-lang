from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter

def test_case_8_0():
    out = Interpreter().run_source('let v8_0 = 0 + 1; v8_0;')
    assert out == 1

def test_case_8_1():
    out = Interpreter().run_source('let v8_1 = 1 + 2; v8_1;')
    assert out == 3

def test_case_8_2():
    out = Interpreter().run_source('let v8_2 = 2 + 3; v8_2;')
    assert out == 5

def test_case_8_3():
    out = Interpreter().run_source('let v8_3 = 3 + 4; v8_3;')
    assert out == 7

def test_case_8_4():
    out = Interpreter().run_source('let v8_4 = 4 + 5; v8_4;')
    assert out == 9

def test_case_8_5():
    out = Interpreter().run_source('let v8_5 = 5 + 6; v8_5;')
    assert out == 11

def test_case_8_6():
    out = Interpreter().run_source('let v8_6 = 6 + 7; v8_6;')
    assert out == 13

def test_case_8_7():
    out = Interpreter().run_source('let v8_7 = 7 + 8; v8_7;')
    assert out == 15

def test_case_8_8():
    out = Interpreter().run_source('let v8_8 = 8 + 9; v8_8;')
    assert out == 17

def test_case_8_9():
    out = Interpreter().run_source('let v8_9 = 9 + 10; v8_9;')
    assert out == 19

def test_case_8_10():
    out = Interpreter().run_source('let v8_10 = 10 + 11; v8_10;')
    assert out == 21

def test_case_8_11():
    out = Interpreter().run_source('let v8_11 = 11 + 12; v8_11;')
    assert out == 23

def test_case_8_12():
    out = Interpreter().run_source('let v8_12 = 12 + 13; v8_12;')
    assert out == 25

def test_case_8_13():
    out = Interpreter().run_source('let v8_13 = 13 + 14; v8_13;')
    assert out == 27

def test_case_8_14():
    out = Interpreter().run_source('let v8_14 = 14 + 15; v8_14;')
    assert out == 29

def test_case_8_15():
    out = Interpreter().run_source('let v8_15 = 15 + 16; v8_15;')
    assert out == 31

def test_case_8_16():
    out = Interpreter().run_source('let v8_16 = 16 + 17; v8_16;')
    assert out == 33

def test_case_8_17():
    out = Interpreter().run_source('let v8_17 = 17 + 18; v8_17;')
    assert out == 35

def test_case_8_18():
    out = Interpreter().run_source('let v8_18 = 18 + 19; v8_18;')
    assert out == 37

def test_case_8_19():
    out = Interpreter().run_source('let v8_19 = 19 + 20; v8_19;')
    assert out == 39
