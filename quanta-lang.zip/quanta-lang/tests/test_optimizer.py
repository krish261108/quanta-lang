from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.optimizer import Optimizer
from quanta.ast import Literal

def test_constant_fold():
    program = Parser(Lexer('1 + 2;').tokenize()).parse()
    optimized = Optimizer().optimize_program(program)
    assert isinstance(optimized.statements[0].expr, Literal)
