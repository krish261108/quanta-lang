from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter

def test_case_11_0():
    out = Interpreter().run_source('let v11_0 = 0 + 1; v11_0;')
    assert out == 1

def test_case_11_1():
    out = Interpreter().run_source('let v11_1 = 1 + 2; v11_1;')
    assert out == 3

def test_case_11_2():
    out = Interpreter().run_source('let v11_2 = 2 + 3; v11_2;')
    assert out == 5

def test_case_11_3():
    out = Interpreter().run_source('let v11_3 = 3 + 4; v11_3;')
    assert out == 7

def test_case_11_4():
    out = Interpreter().run_source('let v11_4 = 4 + 5; v11_4;')
    assert out == 9

def test_case_11_5():
    out = Interpreter().run_source('let v11_5 = 5 + 6; v11_5;')
    assert out == 11

def test_case_11_6():
    out = Interpreter().run_source('let v11_6 = 6 + 7; v11_6;')
    assert out == 13

def test_case_11_7():
    out = Interpreter().run_source('let v11_7 = 7 + 8; v11_7;')
    assert out == 15

def test_case_11_8():
    out = Interpreter().run_source('let v11_8 = 8 + 9; v11_8;')
    assert out == 17

def test_case_11_9():
    out = Interpreter().run_source('let v11_9 = 9 + 10; v11_9;')
    assert out == 19

def test_case_11_10():
    out = Interpreter().run_source('let v11_10 = 10 + 11; v11_10;')
    assert out == 21

def test_case_11_11():
    out = Interpreter().run_source('let v11_11 = 11 + 12; v11_11;')
    assert out == 23

def test_case_11_12():
    out = Interpreter().run_source('let v11_12 = 12 + 13; v11_12;')
    assert out == 25

def test_case_11_13():
    out = Interpreter().run_source('let v11_13 = 13 + 14; v11_13;')
    assert out == 27

def test_case_11_14():
    out = Interpreter().run_source('let v11_14 = 14 + 15; v11_14;')
    assert out == 29

def test_case_11_15():
    out = Interpreter().run_source('let v11_15 = 15 + 16; v11_15;')
    assert out == 31

def test_case_11_16():
    out = Interpreter().run_source('let v11_16 = 16 + 17; v11_16;')
    assert out == 33

def test_case_11_17():
    out = Interpreter().run_source('let v11_17 = 17 + 18; v11_17;')
    assert out == 35

def test_case_11_18():
    out = Interpreter().run_source('let v11_18 = 18 + 19; v11_18;')
    assert out == 37

def test_case_11_19():
    out = Interpreter().run_source('let v11_19 = 19 + 20; v11_19;')
    assert out == 39
