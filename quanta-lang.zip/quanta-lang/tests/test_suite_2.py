from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter
from quanta.compiler import Compiler
from quanta.vm import VM
from quanta.optimizer import Optimizer
from quanta.typechecker import TypeChecker

def test_case2_0():
    source = 'let x = 1 + 2;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_1():
    source = 'let y = 4 * 5;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_2():
    source = 'print 1 + 1;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_3():
    source = 'let a = [1, 2, 3];'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_4():
    source = 'let d = {1: 2};'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_5():
    source = 'if (true) { let z = 3; } else { let z = 4; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_6():
    source = 'while (false) { let n = 0; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_7():
    source = 'fn add(a, b) { return a + b; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_8():
    source = 'let s = "hello";'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_9():
    source = 'let b = !false;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_10():
    source = 'let x = 1 + 2; // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_11():
    source = 'let y = 4 * 5; // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_12():
    source = 'print 1 + 1; // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_13():
    source = 'let a = [1, 2, 3]; // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_14():
    source = 'let d = {1: 2}; // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_15():
    source = 'if (true) { let z = 3; } else { let z = 4; } // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_16():
    source = 'while (false) { let n = 0; } // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_17():
    source = 'fn add(a, b) { return a + b; } // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_18():
    source = 'let s = "hello"; // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case2_19():
    source = 'let b = !false; // 2'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None
