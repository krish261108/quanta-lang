from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter

def test_case_9_0():
    out = Interpreter().run_source('let v9_0 = 0 + 1; v9_0;')
    assert out == 1

def test_case_9_1():
    out = Interpreter().run_source('let v9_1 = 1 + 2; v9_1;')
    assert out == 3

def test_case_9_2():
    out = Interpreter().run_source('let v9_2 = 2 + 3; v9_2;')
    assert out == 5

def test_case_9_3():
    out = Interpreter().run_source('let v9_3 = 3 + 4; v9_3;')
    assert out == 7

def test_case_9_4():
    out = Interpreter().run_source('let v9_4 = 4 + 5; v9_4;')
    assert out == 9

def test_case_9_5():
    out = Interpreter().run_source('let v9_5 = 5 + 6; v9_5;')
    assert out == 11

def test_case_9_6():
    out = Interpreter().run_source('let v9_6 = 6 + 7; v9_6;')
    assert out == 13

def test_case_9_7():
    out = Interpreter().run_source('let v9_7 = 7 + 8; v9_7;')
    assert out == 15

def test_case_9_8():
    out = Interpreter().run_source('let v9_8 = 8 + 9; v9_8;')
    assert out == 17

def test_case_9_9():
    out = Interpreter().run_source('let v9_9 = 9 + 10; v9_9;')
    assert out == 19

def test_case_9_10():
    out = Interpreter().run_source('let v9_10 = 10 + 11; v9_10;')
    assert out == 21

def test_case_9_11():
    out = Interpreter().run_source('let v9_11 = 11 + 12; v9_11;')
    assert out == 23

def test_case_9_12():
    out = Interpreter().run_source('let v9_12 = 12 + 13; v9_12;')
    assert out == 25

def test_case_9_13():
    out = Interpreter().run_source('let v9_13 = 13 + 14; v9_13;')
    assert out == 27

def test_case_9_14():
    out = Interpreter().run_source('let v9_14 = 14 + 15; v9_14;')
    assert out == 29

def test_case_9_15():
    out = Interpreter().run_source('let v9_15 = 15 + 16; v9_15;')
    assert out == 31

def test_case_9_16():
    out = Interpreter().run_source('let v9_16 = 16 + 17; v9_16;')
    assert out == 33

def test_case_9_17():
    out = Interpreter().run_source('let v9_17 = 17 + 18; v9_17;')
    assert out == 35

def test_case_9_18():
    out = Interpreter().run_source('let v9_18 = 18 + 19; v9_18;')
    assert out == 37

def test_case_9_19():
    out = Interpreter().run_source('let v9_19 = 19 + 20; v9_19;')
    assert out == 39
