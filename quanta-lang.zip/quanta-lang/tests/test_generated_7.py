from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter

def test_case_7_0():
    out = Interpreter().run_source('let v7_0 = 0 + 1; v7_0;')
    assert out == 1

def test_case_7_1():
    out = Interpreter().run_source('let v7_1 = 1 + 2; v7_1;')
    assert out == 3

def test_case_7_2():
    out = Interpreter().run_source('let v7_2 = 2 + 3; v7_2;')
    assert out == 5

def test_case_7_3():
    out = Interpreter().run_source('let v7_3 = 3 + 4; v7_3;')
    assert out == 7

def test_case_7_4():
    out = Interpreter().run_source('let v7_4 = 4 + 5; v7_4;')
    assert out == 9

def test_case_7_5():
    out = Interpreter().run_source('let v7_5 = 5 + 6; v7_5;')
    assert out == 11

def test_case_7_6():
    out = Interpreter().run_source('let v7_6 = 6 + 7; v7_6;')
    assert out == 13

def test_case_7_7():
    out = Interpreter().run_source('let v7_7 = 7 + 8; v7_7;')
    assert out == 15

def test_case_7_8():
    out = Interpreter().run_source('let v7_8 = 8 + 9; v7_8;')
    assert out == 17

def test_case_7_9():
    out = Interpreter().run_source('let v7_9 = 9 + 10; v7_9;')
    assert out == 19

def test_case_7_10():
    out = Interpreter().run_source('let v7_10 = 10 + 11; v7_10;')
    assert out == 21

def test_case_7_11():
    out = Interpreter().run_source('let v7_11 = 11 + 12; v7_11;')
    assert out == 23

def test_case_7_12():
    out = Interpreter().run_source('let v7_12 = 12 + 13; v7_12;')
    assert out == 25

def test_case_7_13():
    out = Interpreter().run_source('let v7_13 = 13 + 14; v7_13;')
    assert out == 27

def test_case_7_14():
    out = Interpreter().run_source('let v7_14 = 14 + 15; v7_14;')
    assert out == 29

def test_case_7_15():
    out = Interpreter().run_source('let v7_15 = 15 + 16; v7_15;')
    assert out == 31

def test_case_7_16():
    out = Interpreter().run_source('let v7_16 = 16 + 17; v7_16;')
    assert out == 33

def test_case_7_17():
    out = Interpreter().run_source('let v7_17 = 17 + 18; v7_17;')
    assert out == 35

def test_case_7_18():
    out = Interpreter().run_source('let v7_18 = 18 + 19; v7_18;')
    assert out == 37

def test_case_7_19():
    out = Interpreter().run_source('let v7_19 = 19 + 20; v7_19;')
    assert out == 39
