from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter

def test_case_6_0():
    out = Interpreter().run_source('let v6_0 = 0 + 1; v6_0;')
    assert out == 1

def test_case_6_1():
    out = Interpreter().run_source('let v6_1 = 1 + 2; v6_1;')
    assert out == 3

def test_case_6_2():
    out = Interpreter().run_source('let v6_2 = 2 + 3; v6_2;')
    assert out == 5

def test_case_6_3():
    out = Interpreter().run_source('let v6_3 = 3 + 4; v6_3;')
    assert out == 7

def test_case_6_4():
    out = Interpreter().run_source('let v6_4 = 4 + 5; v6_4;')
    assert out == 9

def test_case_6_5():
    out = Interpreter().run_source('let v6_5 = 5 + 6; v6_5;')
    assert out == 11

def test_case_6_6():
    out = Interpreter().run_source('let v6_6 = 6 + 7; v6_6;')
    assert out == 13

def test_case_6_7():
    out = Interpreter().run_source('let v6_7 = 7 + 8; v6_7;')
    assert out == 15

def test_case_6_8():
    out = Interpreter().run_source('let v6_8 = 8 + 9; v6_8;')
    assert out == 17

def test_case_6_9():
    out = Interpreter().run_source('let v6_9 = 9 + 10; v6_9;')
    assert out == 19

def test_case_6_10():
    out = Interpreter().run_source('let v6_10 = 10 + 11; v6_10;')
    assert out == 21

def test_case_6_11():
    out = Interpreter().run_source('let v6_11 = 11 + 12; v6_11;')
    assert out == 23

def test_case_6_12():
    out = Interpreter().run_source('let v6_12 = 12 + 13; v6_12;')
    assert out == 25

def test_case_6_13():
    out = Interpreter().run_source('let v6_13 = 13 + 14; v6_13;')
    assert out == 27

def test_case_6_14():
    out = Interpreter().run_source('let v6_14 = 14 + 15; v6_14;')
    assert out == 29

def test_case_6_15():
    out = Interpreter().run_source('let v6_15 = 15 + 16; v6_15;')
    assert out == 31

def test_case_6_16():
    out = Interpreter().run_source('let v6_16 = 16 + 17; v6_16;')
    assert out == 33

def test_case_6_17():
    out = Interpreter().run_source('let v6_17 = 17 + 18; v6_17;')
    assert out == 35

def test_case_6_18():
    out = Interpreter().run_source('let v6_18 = 18 + 19; v6_18;')
    assert out == 37

def test_case_6_19():
    out = Interpreter().run_source('let v6_19 = 19 + 20; v6_19;')
    assert out == 39
