from quanta.lexer import Lexer
from quanta.token import TokenKind

def test_tokenize_simple():
    toks = Lexer('let x = 3 + 4;').tokenize()
    assert toks[0].kind == TokenKind.LET
    assert any(t.kind == TokenKind.NUMBER for t in toks)
