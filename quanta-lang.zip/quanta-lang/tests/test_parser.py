from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.ast import Let, Function

def test_parse_let():
    p = Parser(Lexer('let x = 2;').tokenize()).parse()
    assert isinstance(p.statements[0], Let)

def test_parse_fn():
    p = Parser(Lexer('fn add(a, b) { return a + b; }').tokenize()).parse()
    assert isinstance(p.statements[0], Function)
