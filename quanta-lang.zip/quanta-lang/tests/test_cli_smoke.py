from quanta.cli import main

def test_cli_smoke():
    assert main([]) is None
