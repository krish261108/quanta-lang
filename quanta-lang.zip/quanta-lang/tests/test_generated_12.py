from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter

def test_case_12_0():
    out = Interpreter().run_source('let v12_0 = 0 + 1; v12_0;')
    assert out == 1

def test_case_12_1():
    out = Interpreter().run_source('let v12_1 = 1 + 2; v12_1;')
    assert out == 3

def test_case_12_2():
    out = Interpreter().run_source('let v12_2 = 2 + 3; v12_2;')
    assert out == 5

def test_case_12_3():
    out = Interpreter().run_source('let v12_3 = 3 + 4; v12_3;')
    assert out == 7

def test_case_12_4():
    out = Interpreter().run_source('let v12_4 = 4 + 5; v12_4;')
    assert out == 9

def test_case_12_5():
    out = Interpreter().run_source('let v12_5 = 5 + 6; v12_5;')
    assert out == 11

def test_case_12_6():
    out = Interpreter().run_source('let v12_6 = 6 + 7; v12_6;')
    assert out == 13

def test_case_12_7():
    out = Interpreter().run_source('let v12_7 = 7 + 8; v12_7;')
    assert out == 15

def test_case_12_8():
    out = Interpreter().run_source('let v12_8 = 8 + 9; v12_8;')
    assert out == 17

def test_case_12_9():
    out = Interpreter().run_source('let v12_9 = 9 + 10; v12_9;')
    assert out == 19

def test_case_12_10():
    out = Interpreter().run_source('let v12_10 = 10 + 11; v12_10;')
    assert out == 21

def test_case_12_11():
    out = Interpreter().run_source('let v12_11 = 11 + 12; v12_11;')
    assert out == 23

def test_case_12_12():
    out = Interpreter().run_source('let v12_12 = 12 + 13; v12_12;')
    assert out == 25

def test_case_12_13():
    out = Interpreter().run_source('let v12_13 = 13 + 14; v12_13;')
    assert out == 27

def test_case_12_14():
    out = Interpreter().run_source('let v12_14 = 14 + 15; v12_14;')
    assert out == 29

def test_case_12_15():
    out = Interpreter().run_source('let v12_15 = 15 + 16; v12_15;')
    assert out == 31

def test_case_12_16():
    out = Interpreter().run_source('let v12_16 = 16 + 17; v12_16;')
    assert out == 33

def test_case_12_17():
    out = Interpreter().run_source('let v12_17 = 17 + 18; v12_17;')
    assert out == 35

def test_case_12_18():
    out = Interpreter().run_source('let v12_18 = 18 + 19; v12_18;')
    assert out == 37

def test_case_12_19():
    out = Interpreter().run_source('let v12_19 = 19 + 20; v12_19;')
    assert out == 39
