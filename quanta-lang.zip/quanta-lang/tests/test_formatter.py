from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.formatter import Formatter

def test_format_roundtrip():
    program = Parser(Lexer('let x = 1 + 2;').tokenize()).parse()
    text = Formatter().format_program(program)
    assert 'let x' in text
