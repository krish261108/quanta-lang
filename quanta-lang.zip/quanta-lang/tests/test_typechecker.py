from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.typechecker import TypeChecker

def test_typecheck_runs():
    program = Parser(Lexer('let x = 1;').tokenize()).parse()
    TypeChecker().check(program)
