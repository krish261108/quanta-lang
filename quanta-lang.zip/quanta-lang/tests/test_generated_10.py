from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter

def test_case_10_0():
    out = Interpreter().run_source('let v10_0 = 0 + 1; v10_0;')
    assert out == 1

def test_case_10_1():
    out = Interpreter().run_source('let v10_1 = 1 + 2; v10_1;')
    assert out == 3

def test_case_10_2():
    out = Interpreter().run_source('let v10_2 = 2 + 3; v10_2;')
    assert out == 5

def test_case_10_3():
    out = Interpreter().run_source('let v10_3 = 3 + 4; v10_3;')
    assert out == 7

def test_case_10_4():
    out = Interpreter().run_source('let v10_4 = 4 + 5; v10_4;')
    assert out == 9

def test_case_10_5():
    out = Interpreter().run_source('let v10_5 = 5 + 6; v10_5;')
    assert out == 11

def test_case_10_6():
    out = Interpreter().run_source('let v10_6 = 6 + 7; v10_6;')
    assert out == 13

def test_case_10_7():
    out = Interpreter().run_source('let v10_7 = 7 + 8; v10_7;')
    assert out == 15

def test_case_10_8():
    out = Interpreter().run_source('let v10_8 = 8 + 9; v10_8;')
    assert out == 17

def test_case_10_9():
    out = Interpreter().run_source('let v10_9 = 9 + 10; v10_9;')
    assert out == 19

def test_case_10_10():
    out = Interpreter().run_source('let v10_10 = 10 + 11; v10_10;')
    assert out == 21

def test_case_10_11():
    out = Interpreter().run_source('let v10_11 = 11 + 12; v10_11;')
    assert out == 23

def test_case_10_12():
    out = Interpreter().run_source('let v10_12 = 12 + 13; v10_12;')
    assert out == 25

def test_case_10_13():
    out = Interpreter().run_source('let v10_13 = 13 + 14; v10_13;')
    assert out == 27

def test_case_10_14():
    out = Interpreter().run_source('let v10_14 = 14 + 15; v10_14;')
    assert out == 29

def test_case_10_15():
    out = Interpreter().run_source('let v10_15 = 15 + 16; v10_15;')
    assert out == 31

def test_case_10_16():
    out = Interpreter().run_source('let v10_16 = 16 + 17; v10_16;')
    assert out == 33

def test_case_10_17():
    out = Interpreter().run_source('let v10_17 = 17 + 18; v10_17;')
    assert out == 35

def test_case_10_18():
    out = Interpreter().run_source('let v10_18 = 18 + 19; v10_18;')
    assert out == 37

def test_case_10_19():
    out = Interpreter().run_source('let v10_19 = 19 + 20; v10_19;')
    assert out == 39
