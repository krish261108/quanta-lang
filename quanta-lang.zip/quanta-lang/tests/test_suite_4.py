from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter
from quanta.compiler import Compiler
from quanta.vm import VM
from quanta.optimizer import Optimizer
from quanta.typechecker import TypeChecker

def test_case4_0():
    source = 'let x = 1 + 2;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_1():
    source = 'let y = 4 * 5;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_2():
    source = 'print 1 + 1;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_3():
    source = 'let a = [1, 2, 3];'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_4():
    source = 'let d = {1: 2};'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_5():
    source = 'if (true) { let z = 3; } else { let z = 4; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_6():
    source = 'while (false) { let n = 0; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_7():
    source = 'fn add(a, b) { return a + b; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_8():
    source = 'let s = "hello";'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_9():
    source = 'let b = !false;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_10():
    source = 'let x = 1 + 2; // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_11():
    source = 'let y = 4 * 5; // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_12():
    source = 'print 1 + 1; // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_13():
    source = 'let a = [1, 2, 3]; // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_14():
    source = 'let d = {1: 2}; // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_15():
    source = 'if (true) { let z = 3; } else { let z = 4; } // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_16():
    source = 'while (false) { let n = 0; } // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_17():
    source = 'fn add(a, b) { return a + b; } // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_18():
    source = 'let s = "hello"; // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case4_19():
    source = 'let b = !false; // 4'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None
