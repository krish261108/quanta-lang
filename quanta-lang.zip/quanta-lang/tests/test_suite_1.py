from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter
from quanta.compiler import Compiler
from quanta.vm import VM
from quanta.optimizer import Optimizer
from quanta.typechecker import TypeChecker

def test_case1_0():
    source = 'let x = 1 + 2;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_1():
    source = 'let y = 4 * 5;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_2():
    source = 'print 1 + 1;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_3():
    source = 'let a = [1, 2, 3];'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_4():
    source = 'let d = {1: 2};'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_5():
    source = 'if (true) { let z = 3; } else { let z = 4; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_6():
    source = 'while (false) { let n = 0; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_7():
    source = 'fn add(a, b) { return a + b; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_8():
    source = 'let s = "hello";'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_9():
    source = 'let b = !false;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_10():
    source = 'let x = 1 + 2; // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_11():
    source = 'let y = 4 * 5; // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_12():
    source = 'print 1 + 1; // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_13():
    source = 'let a = [1, 2, 3]; // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_14():
    source = 'let d = {1: 2}; // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_15():
    source = 'if (true) { let z = 3; } else { let z = 4; } // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_16():
    source = 'while (false) { let n = 0; } // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_17():
    source = 'fn add(a, b) { return a + b; } // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_18():
    source = 'let s = "hello"; // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case1_19():
    source = 'let b = !false; // 1'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None
