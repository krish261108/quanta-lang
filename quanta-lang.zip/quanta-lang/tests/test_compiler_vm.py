from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.compiler import Compiler
from quanta.vm import VM

def test_vm_executes():
    program = Parser(Lexer('let x = 3; x;').tokenize()).parse()
    code = Compiler().compile(program)
    vm = VM()
    vm.run(code)
