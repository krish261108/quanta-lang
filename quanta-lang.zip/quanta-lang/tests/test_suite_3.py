from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.interpreter import Interpreter
from quanta.compiler import Compiler
from quanta.vm import VM
from quanta.optimizer import Optimizer
from quanta.typechecker import TypeChecker

def test_case3_0():
    source = 'let x = 1 + 2;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_1():
    source = 'let y = 4 * 5;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_2():
    source = 'print 1 + 1;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_3():
    source = 'let a = [1, 2, 3];'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_4():
    source = 'let d = {1: 2};'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_5():
    source = 'if (true) { let z = 3; } else { let z = 4; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_6():
    source = 'while (false) { let n = 0; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_7():
    source = 'fn add(a, b) { return a + b; }'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_8():
    source = 'let s = "hello";'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_9():
    source = 'let b = !false;'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_10():
    source = 'let x = 1 + 2; // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_11():
    source = 'let y = 4 * 5; // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_12():
    source = 'print 1 + 1; // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_13():
    source = 'let a = [1, 2, 3]; // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_14():
    source = 'let d = {1: 2}; // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_15():
    source = 'if (true) { let z = 3; } else { let z = 4; } // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_16():
    source = 'while (false) { let n = 0; } // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_17():
    source = 'fn add(a, b) { return a + b; } // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_18():
    source = 'let s = "hello"; // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None

def test_case3_19():
    source = 'let b = !false; // 3'
    tokens = Lexer(source).tokenize()
    program = Parser(tokens).parse()
    TypeChecker().check(program)
    program = Optimizer().optimize_program(program)
    interp = Interpreter()
    result = interp.tree.run(program)
    assert result is not None or result is None
