from quanta.interpreter import Interpreter

def test_run_source():
    out = Interpreter().run_source('let x = 4; let y = 6; x + y;')
    assert out == 10
