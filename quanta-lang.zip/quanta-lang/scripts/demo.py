from quanta.interpreter import Interpreter

source = """
let x = 4;
let y = 8;
print x + y;
"""

Interpreter().run_source(source)
