from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.analysis.metrics import summarize
from quanta.compiler import Compiler

src = 'let x = 10; let y = 20; x + y;'
program = Parser(Lexer(src).tokenize()).parse()
code = Compiler().compile(program)
print(summarize(code))
