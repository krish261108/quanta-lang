from quanta.lexer import Lexer
from quanta.parser import Parser
from quanta.compiler import Compiler
from quanta.vm import VM

src = 'let x = 1 + 2 * 3; x;'
program = Parser(Lexer(src).tokenize()).parse()
code = Compiler().compile(program)
print({'instructions': len(code.instructions), 'constants': len(code.constants), 'names': len(code.names)})
print(VM().run(code))
